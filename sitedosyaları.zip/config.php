<?php

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "fivem";

$enablemail = true;

$emailserverhost = "server3.poyrazhosting.com";
$emailserverid = "test@fsnhost.com";
$emailserverpass = "deneme123ata313131";

$link = "https://localhost";